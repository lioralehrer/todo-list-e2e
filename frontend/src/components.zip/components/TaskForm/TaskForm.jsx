import React from "react";

class TasksForm extends React.Component {
    constructor() {
        super();
        this.handleInputChange = this.handleInputChange.bind(this);
        this.handleSubmitTask = this.handleSubmitTask.bind(this);
        this.state = (
            {
                task: "",
                description: ""
            }
        )
    }
    handleInputChange(e) {
        let inputValue = e.target.value;
        let stateKey = e.target.getAttribute("data-bind");
        this.setState({
            [stateKey]: inputValue,
        })
    }
    handleSubmitTask(e) {
        this.props.handleNewTask(Object.assign({}, this.state));
    }
    render() {
        return (
            <div >
                <span className="glyphicon glyphicon-list"></span>
                <input className="task-input " data-bind="task" onChange={this.handleInputChange} type="text" placeholder="task:" />
                <span className="glyphicon glyphicon-list"></span>
                <input className="task-input " data-bind="description" onChange={this.handleInputChange} type="text" placeholder="discription:" />
                <label>Insert Priority 1-5</label>
                <input ></input>
                <button onClick={this.handleSubmitTask} className="btn btn-success">Submit task</button>

            </div>
        )
    }
}
export default TasksForm;